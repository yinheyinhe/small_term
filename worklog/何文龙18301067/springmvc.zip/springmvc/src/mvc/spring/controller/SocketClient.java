package mvc.spring.controller;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import org.apache.commons.io.*;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

public class SocketClient implements Runnable{
	private Socket socket;
	private PrintWriter pw;	
	private InputStream is;
	private BufferedReader in;
	private String name;
	private	String Password;
	public String[] x=new String[5];
	public String[] y=new String[5];
	public SocketClient(){
		setName("www");
		setPassword("hhh");
		try {
			socket = new Socket("localhost",8001);
			OutputStream os=socket.getOutputStream();
			pw=new PrintWriter(os);//将输出流包装为打印流
			is=socket.getInputStream();
	        in = new BufferedReader(new InputStreamReader(is));//将输入流打包为输入流
	        
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean Registe(String name,String Password) throws IOException{
		this.name=name;
		this.Password=Password;
		pw.write("register_"+name+"_"+Password);
		pw.flush();
		
		String registe_flag=in.readLine();
		if(registe_flag.equalsIgnoreCase("yes")){
			return true;
		}
		else{
			return false;
		}
				
	}
	
	public boolean Sign(String name,String Password) throws IOException{
		this.name=name;
		this.Password=Password;
		pw.write("sign"+"_"+name+"_"+Password);
		pw.flush();
		
		String Sign_flag=in.readLine();
		if(Sign_flag.equalsIgnoreCase("yes")){			
			return true;
		}
		else{
			return false;
		}
	}

	public boolean delete(String name,String Password) throws IOException{
		this.name=name;
		this.Password=Password;
		pw.write("delete_"+name+"_"+Password);
		pw.flush();
		
		String delete_flag=in.readLine();
		if(delete_flag.equalsIgnoreCase("yes")){
			return true;
		}
		else{
			return false;
		}
	}
	//close output and input stream
	public void closeall() throws IOException{
        is.close();
        in.close();
        socket.close();
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}
	
	public void readjson() throws IOException
	{
		
		
		File file = new File("D:/test/data.json");
		FileInputStream in=new FileInputStream(file);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();  
        int j;  
        while ((j = in.read()) != -1) {  
        baos.write(j);  
        }  

        String content=baos.toString();
        JSONObject jsonObject = new JSONObject(content);
        JSONArray jsonArray = (JSONArray) jsonObject.get("data");
        for(int i=0;i<5;i++){
        	JSONObject job = jsonArray.getJSONObject(i);        	
        	x[i]=String.valueOf(job.get("t_max"));       	
        	y[i]=String.valueOf(job.get("t_min"));
        }       
    }
	
	public boolean Change(String Password,String newPass) throws IOException{
		return true;
	
	}
	public void sendfile() throws IOException{
		pw.write("sendfile_"+name+"_"+Password);
		pw.flush();
		DataInputStream din=new DataInputStream(new BufferedInputStream(is));
        File f=new File("D:/test/data.json");
        RandomAccessFile fw=new RandomAccessFile(f,"rw");
        byte[] b=new byte[1024];
		int num = din.read(b);
		while(num!=-1){
        	fw.write(b,0,num);
        	fw.skipBytes(num);
        	num=din.read(b);
		
		}
		
	}

	public void run() {
		try {
			sendfile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	

}
