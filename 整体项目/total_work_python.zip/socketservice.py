import socket, os, json,time


from threading import Thread

from myMYSQL import MyUserSql

from model import model

ADDRESS = ('localhost', 8001)

g_conn_pool = []

g_socket_server=None

mysql = MyUserSql()

def other():
    m=model()
    m.draw()
def init():
    global g_socket_server
    g_socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
    print("create socket succ!")

    g_socket_server.bind(('localhost', 8001))
    print('bind socket succ!')

    g_socket_server.listen(5)
    print('listen succ!')


def message_handle(client):
    while True:
        szBuf = client.recv(1024)
        buffer=str(szBuf, 'gbk')
        str1,str2,str3=buffer.split("_")
        print(str1+"  "+str2+"   "+str3)
        if str1=='register':
            if mysql.isExist(str2,str3):
                client.send(b'no\n')
                print("failed1")
            else:
                if mysql.insertUser(str2, str3):
                    client.send(b"yes\n")
                    print("success")
                else:
                    client.send(b"no\n")
                    print('failed2')

        if str1=='sign':
            if mysql.isExist(str2,str3):
                client.send(b"yes\n")
            else:
                client.send(b"no\n")
        if str1=='delete':
            if mysql.isExist(str2,str3):
                if mysql.deleteUser(str2):
                    client.send(b"yes\n")
                else:
                    client.send(b"no\n")
        if str1=='sendfile':
            filename = r"D:\pythonfiles\datas\data1.json"
            myfile = open(filename, 'rb')
            for readline in myfile:
                client.send(readline)
        if str1=='change':
            if mysql.changeUser(str2,str2,str3):
                client.send(b'yes\n')
            else:
                client.send(b'no\n')

    conn.close()
    print("end of servive")

def acceptclient():
    while True:
        print("listen for client...")
        client, addr = g_socket_server.accept()
        print("get client")
        g_conn_pool.append(client)
        thread = Thread(target=message_handle, args=(client,))
        thread.start()
if __name__ == '__main__':
    init()
    
    other()
    # 新开一个线程，用于接收新连接
    thread = Thread(target=acceptclient)
    thread.setDaemon(True)
    thread.start()
    while True:
        time.sleep(40000)

